print(1)
import psycopg2
print(2)
